# NetSage AI — Project 2 Submission

## Deliverables
- `cases.csv` — 30 structured troubleshooting cases.
- `diagnose_prompt.md` — structured AI prompt and worked example.
- `rule_checker.py` — deterministic Python sanity checker with sample output.
- `responsible_ai_log.csv` — five human correction records.
- `app.py` — integrated Streamlit dashboard/demo application.

## Requirement coverage
1. Case dataset: 30 cases spanning the required networking fault families.
2. Evidence: symptom, topology note, show outputs, expected fault, OSI layer, concept tag, severity.
3. AI prompt: structured JSON fields `root_cause`, `confidence`, `evidence`, `next_command`, `fix_steps`.
4. Rule checker: deterministic checks for common configuration mistakes.
5. Human review: Accepted / Edited / Rejected workflow is represented in the integrated app.
6. Responsible AI: five corrected AI cases are logged.
7. Dashboard: case themes, review agreement and escalation metrics.

## Run
```bash
pip install streamlit pandas plotly
streamlit run app.py
```

## Important implementation note
The supplied original response uses a simulated AI engine. This submission preserves that framing rather than claiming a live LLM integration.

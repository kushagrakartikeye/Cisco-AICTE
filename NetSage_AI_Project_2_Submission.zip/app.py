import streamlit as st
import pandas as pd
import plotly.express as px
from rule_checker import deterministic_rule_checker

st.set_page_config(page_title="NetSage AI", layout="wide")

@st.cache_data
def load_cases():
    return pd.read_csv("cases.csv")

def simulated_ai(case):
    return {
        "root_cause": f"Likely {case['concept_tag']} failure: {case['expected_fault']}",
        "confidence": "High",
        "evidence": f"The supplied show-command evidence is consistent with {case['expected_fault']}.",
        "next_command": f"show run | section {str(case['concept_tag']).split()[0].lower()}",
        "fix_steps": f"Verify the affected configuration and correct the parameter responsible for {case['expected_fault']}."
    }

cases=load_cases()
if "reviews" not in st.session_state:
    st.session_state.reviews={}

st.title("NetSage AI — Network Troubleshooting Dashboard")
st.caption("AI-assisted Cisco Packet Tracer diagnostics with mandatory human review.")

tab1,tab2,tab3,tab4=st.tabs(["Diagnostics Workbench","Analytics","Responsible AI Log","Prompt Library"])

with tab1:
    choice=st.selectbox("Select case", cases["case_id"].tolist())
    case=cases[cases.case_id==choice].iloc[0]
    left,right=st.columns([1,2])
    with left:
        st.info(f"OSI: {case.osi_layer} | Severity: {case.severity}")
        st.markdown(f"**Symptom**  
{case.symptom}")
        st.markdown(f"**Topology note**  
{case.topology_note}")
        st.markdown(f"**Expected fault**  
{case.expected_fault}")
    with right:
        st.subheader("Show-command evidence")
        st.code(case.show_outputs)
    rr=deterministic_rule_checker(case.show_outputs,case.symptom)
    if rr["flagged"]: st.warning(f"Rule checker: {rr['fault']} ({rr['layer']}) — {rr['reason']}")
    else: st.success("Rule checker: no explicit deterministic match.")
    ai=simulated_ai(case)
    st.subheader("AI Diagnosis")
    for k,v in ai.items(): st.write(f"**{k.replace('_',' ').title()}:** {v}")
    st.subheader("Human Review")
    old=st.session_state.reviews.get(choice,{"status":"Pending","notes":"","corrected_cause":ai["root_cause"],"corrected_layer":case.osi_layer})
    status=st.radio("Decision",["Pending","Accepted","Edited","Rejected"],index=["Pending","Accepted","Edited","Rejected"].index(old["status"]))
    cause=st.text_input("Corrected root cause",old["corrected_cause"])
    layer=st.selectbox("Corrected OSI layer",["Layer 1","Layer 2","Layer 3","Layer 4","Layer 7"],index=["Layer 1","Layer 2","Layer 3","Layer 4","Layer 7"].index(old["corrected_layer"]))
    notes=st.text_area("Reviewer rationale",old["notes"])
    if st.button("Commit review"):
        st.session_state.reviews[choice]={"status":status,"notes":notes,"corrected_cause":cause,"corrected_layer":layer}
        st.success("Review committed.")

with tab2:
    reviewed=[v for v in st.session_state.reviews.values() if v["status"]!="Pending"]
    accepted=sum(v["status"]=="Accepted" for v in reviewed)
    edited=sum(v["status"]=="Edited" for v in reviewed)
    rejected=sum(v["status"]=="Rejected" for v in reviewed)
    c1,c2,c3,c4=st.columns(4)
    c1.metric("Total cases",len(cases)); c2.metric("Reviewed",len(reviewed))
    c3.metric("Agreement rate",f"{accepted/len(reviewed)*100:.1f}%" if reviewed else "0.0%")
    c4.metric("Escalations",edited+rejected)
    counts=cases["concept_tag"].value_counts().reset_index()
    counts.columns=["Concept","Count"]
    st.plotly_chart(px.bar(counts,x="Concept",y="Count"),use_container_width=True)

with tab3:
    rows=[]
    for cid,r in st.session_state.reviews.items():
        if r["status"] in ("Edited","Rejected"):
            rows.append({"Case ID":cid,**r})
    st.dataframe(pd.DataFrame(rows),use_container_width=True) if rows else st.info("No live corrections yet. Five baseline corrections are included in responsible_ai_log.csv.")

with tab4:
    st.code(open("diagnose_prompt.md",encoding="utf-8").read(),language="markdown")

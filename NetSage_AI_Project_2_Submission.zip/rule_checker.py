"""NetSage AI deterministic sanity checker."""
def deterministic_rule_checker(show_output: str, symptom: str = "") -> dict:
    out = show_output.lower()
    # Interface down
    if "administratively down" in out or "protocol is down" in out:
        return {"flagged": True, "fault": "Interface Down", "layer": "Layer 1",
                "reason": "Interface output indicates an administratively or protocol-down state."}
    # Duplicate IP
    if "duplicate ip address" in out or out.count("10.0.0.15") >= 2:
        return {"flagged": True, "fault": "IP Duplicate", "layer": "Layer 3",
                "reason": "Repeated/duplicate IP-address evidence detected."}
    # Missing trunk
    if "show interfaces trunk" in out and ("empty" in out or "no active trunks" in out):
        return {"flagged": True, "fault": "VLAN Trunking", "layer": "Layer 2",
                "reason": "No active trunk evidence found on the inter-switch link."}
    # DHCP relay
    if "no helper address" in out:
        return {"flagged": True, "fault": "DHCP Relay", "layer": "Layer 3",
                "reason": "No DHCP helper-address configuration is present."}
    # Explicit mismatch wording
    if "subnet mask" in out and "mismatch" in out:
        return {"flagged": True, "fault": "Wrong Mask", "layer": "Layer 3",
                "reason": "Evidence indicates a subnet-mask mismatch."}
    return {"flagged": False, "fault": "None", "layer": "None",
            "reason": "No deterministic rule matched; proceed to AI analysis and human review."}

if __name__ == "__main__":
    samples = [
        ("Router# show interfaces Gi0/0\nGi0/0 is administratively down, line protocol is down", "Gateway unreachable"),
        ("Switch# show interfaces trunk\n(Outputs empty, no active trunks found)", "Inter-switch connectivity fails"),
    ]
    for output, symptom in samples:
        print(deterministic_rule_checker(output, symptom))
